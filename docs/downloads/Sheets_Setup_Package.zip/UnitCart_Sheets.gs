/**
 * 한눈단가 · Google Sheets 보조 도구 v1.0
 * @OnlyCurrentDoc
 * 현재 스프레드시트의 상품·판매가 입력 칸만 읽고 씁니다.
 * 쇼핑몰 자동 수집, 외부 전송, API 키, 예약 실행을 사용하지 않습니다.
 * 네이버 쇼핑 검색 API 종료: https://developers.naver.com/notice/article/32564
 */

var UC = {
  headerRow: 7, firstRow: 8,
  products: { name: '상품', capacity: 100, id: '상품ID',
    fields: ['상품ID','상품명','브랜드·모델/규격','검색어','비교단위','코스트코 결제금액','총량','직접입력 단가','확인일','데이터구분','메모'] },
  offers: { name: '판매가', capacity: 400, id: '판매가ID',
    fields: ['판매가ID','상품ID','플랫폼','판매처','상품명','일치유형','비교단위','총량','상품가격','배송비','적용할인','할인확인','배송유형','공식몰확인','공식몰근거URL','상품URL','확인일','재고','검증상태','데이터구분','메모'] },
  units: ['개','100g','100mL','m'],
  deliveries: ['로켓배송','로켓프레시','판매자로켓','일반배송','해당없음'],
  maxBytes: 1000000,
  categoryPrefix: 'unitcart.category.',
  metadataKey: 'unitcart.settings'
};

function onOpen() {
  SpreadsheetApp.getUi().createMenu('한눈단가')
    .addItem('선택 상품 검색 · 판매가 입력', 'showUnitCartEntry')
    .addItem('선택 판매가 확인일을 오늘로', 'stampSelectedOfferDate')
    .addSeparator()
    .addItem('사이트 JSON 가져오기', 'showUnitCartImport')
    .addItem('사이트용 JSON 내보내기', 'showUnitCartExport')
    .addSeparator()
    .addItem('사용 안내', 'showUnitCartHelp')
    .addToUi();
}

function showUnitCartHelp() {
  SpreadsheetApp.getUi().alert('한눈단가',
    '상품 시트의 상품 행을 선택한 뒤 “선택 상품 검색 · 판매가 입력”을 누르세요.\n\n' +
    '쇼핑몰에서 가격·옵션·총량·배송비를 확인하여 입력하면 기존 시트 수식이 비교합니다. 검색 링크는 공식몰이나 로켓배송을 자동 인증하지 않습니다.\n\n' +
    '검색어의 앞뒤 공백을 제거하고, 비어 있으면 상품명으로 검색합니다. 네이버 검색어에 공식을 강제로 붙이지 않습니다.\n\n' +
    '사이트 JSON 가져오기는 기본적으로 신규 ID만 추가합니다. “기존 ID도 갱신”을 직접 선택한 경우에만 같은 ID의 입력 칸을 덮어씁니다. 수식, 서식, 기록이 없는 다른 행은 보존합니다.\n\n' +
    '사이트의 사진으로 등록은 기기 안에서 사진을 읽습니다. 인식값을 확인·저장한 뒤 데이터·시트에서 전체 JSON을 내보내 이 메뉴로 가져오세요. 상품 값은 옮겨지고 원본 사진은 시트에 저장되지 않습니다. 온라인 가격은 자동 조회하지 않습니다.\n\n' +
    '상품 100개, 판매가 400개까지 지원합니다. 네이버 쇼핑 API가 종료되어 이 도구는 자동 가격 조회를 제공하지 않습니다.',
    SpreadsheetApp.getUi().ButtonSet.OK);
}

function showUnitCartEntry() {
  try {
    var product = selectedProduct_();
    var title = product ? product.name : '상품을 먼저 선택하세요';
    var body = '<h1>판매가 기록</h1><p id="productName"></p>' +
      '<div class="links"><a id="coupang" target="_blank" rel="noopener noreferrer">쿠팡 검색</a>' +
      '<a id="naver" target="_blank" rel="noopener noreferrer">네이버 검색</a></div>' +
      '<p class="note">입력한 검색어로 후보를 찾습니다. 공식이라는 검색어는 공식몰 필터가 아닙니다. 로켓배송·공식판매처 여부와 구매 옵션을 직접 확인해 주세요.</p>' +
      '<form id="entry"><label>플랫폼<select name="platform"><option>쿠팡</option><option>네이버</option></select></label>' +
      '<label>판매처<input name="seller" maxlength="500" required></label>' +
      '<label>판매 상품명<input name="name" maxlength="500" required></label>' +
      '<label>제품 일치<select name="match"><option>동일</option><option>유사</option></select></label>' +
      '<label>총량 <span id="unitHint"></span><input name="quantity" type="number" step="any" min="0.000001" required></label>' +
      '<div class="two"><label>상품가격 (원)<input name="price" type="number" min="0.01" step="any" required></label>' +
      '<label>배송비 (원)<input name="shipping" type="number" min="0" step="any" placeholder="미확인은 빈칸"></label></div>' +
      '<label>실제 적용 할인 (원)<input name="discount" type="number" min="0" step="any" value="0"></label>' +
      '<label class="check"><input name="discountConfirmed" type="checkbox">할인이 실제 적용됨을 확인</label>' +
      '<label>배송 유형<select name="delivery"><option>로켓배송</option><option>로켓프레시</option><option>판매자로켓</option><option>일반배송</option><option>해당없음</option></select></label>' +
      '<label>상품 링크<input name="url" type="url" maxlength="2048" placeholder="https://..."></label>' +
      '<label class="check"><input name="official" type="checkbox">네이버 공식판매처 직접 확인</label>' +
      '<label>공식판매처 확인 근거 URL<input name="officialEvidenceUrl" type="url" maxlength="2048" placeholder="공식 표시를 확인한 페이지"></label>' +
      '<label>재고<select name="stock"><option>미확인</option><option>있음</option><option>품절</option></select></label>' +
      '<label>가격 확인일<input name="verifiedAt" type="date" required></label>' +
      '<label class="check"><input name="verified" type="checkbox">상품·옵션·가격·배송비를 확인했습니다</label>' +
      '<label>메모<textarea name="note" rows="2" maxlength="2000"></textarea></label>' +
      '<button id="save" type="submit">판매가 추가</button></form><p id="status" role="status"></p>';
    var seed = {product:product, today:today_(), title:title};
    var script = 'var seed=' + scriptJson_(seed) + ';' +
      'document.getElementById("productName").textContent=seed.title;' +
      'if(!seed.product){document.getElementById("entry").hidden=true;document.querySelector(".links").hidden=true;document.getElementById("status").textContent="상품·비교요약·판매가 시트에서 상품이 있는 행을 선택하고 다시 열어 주세요.";}else{' +
      'var p=seed.product, f=document.getElementById("entry"), query=String(p.query||"").trim()||String(p.name||"").trim();' +
      'document.getElementById("coupang").href="https://www.coupang.com/np/search?q="+encodeURIComponent(query);' +
      'document.getElementById("naver").href="https://search.shopping.naver.com/search/all?query="+encodeURIComponent(query);' +
      'f.elements.name.value=p.name;f.elements.verifiedAt.value=seed.today;' +
      'document.getElementById("unitHint").textContent=p.unit==="100g"?"(g)":p.unit==="100mL"?"(mL)":"("+p.unit+")";' +
      'f.addEventListener("submit",function(e){e.preventDefault();var o={productId:p.id,unit:p.unit,isExample:p.isExample};' +
      'Array.from(f.elements).forEach(function(el){if(el.name)o[el.name]=el.type==="checkbox"?el.checked:el.value;});' +
      'document.getElementById("save").disabled=true;document.getElementById("status").textContent="저장 중…";' +
      'google.script.run.withSuccessHandler(function(r){document.getElementById("status").textContent=r.message;f.reset();f.elements.name.value=p.name;f.elements.verifiedAt.value=seed.today;document.getElementById("save").disabled=false;})' +
      '.withFailureHandler(function(e){document.getElementById("status").textContent=e.message;document.getElementById("save").disabled=false;}).appendUnitCartOffer(o);});}';
    SpreadsheetApp.getUi().showSidebar(html_(body, script).setTitle('한눈단가 · 판매가 기록'));
  } catch (e) { SpreadsheetApp.getUi().alert(e.message); }
}

function appendUnitCartOffer(input) {
  var productId = cleanId_(input.productId, '상품ID');
  var products = exportProductRows_();
  var product = products.filter(function(p){return p.id === productId;})[0];
  if (!product) throw new Error('상품을 찾을 수 없습니다. 먼저 상품 시트에 등록하세요.');
  var o = Object.assign({}, input, {id:'O-'+Utilities.getUuid(), productId:productId, unit:product.unit, isExample:product.isExample});
  ['quantity','price','shipping','discount'].forEach(function(k){o[k] = o[k] === '' ? null : Number(o[k]);});
  var packet = {schemaVersion:1,products:[],offers:[o]};
  var result = importUnitCartJson(JSON.stringify(packet), false, false);
  return {message: '판매가 1건을 추가했습니다. 비교요약에서 결과와 제외 사유를 확인하세요.', result:result};
}

function stampSelectedOfferDate() {
  var ss = SpreadsheetApp.getActiveSpreadsheet(), range = ss.getActiveRange();
  if (!range || range.getSheet().getName() !== UC.offers.name || range.getRow()<UC.firstRow || range.getLastRow()>UC.firstRow+UC.offers.capacity-1) {
    SpreadsheetApp.getUi().alert('판매가 시트의 데이터 행(8~407행)을 선택하세요.'); return;
  }
  var ctx = context_(UC.offers), rows = [];
  for(var r=range.getRow();r<=range.getLastRow();r++) if(ctx.sheet.getRange(r,ctx.map['판매가ID']).getValue()!=='') rows.push(r);
  if(!rows.length){SpreadsheetApp.getUi().alert('선택한 행에 판매가ID가 없습니다.');return;}
  var ui=SpreadsheetApp.getUi();
  var answer=ui.alert('확인일 갱신', rows.length+'개 판매가의 가격을 오늘 직접 확인하셨나요? 확인일만 오늘로 바꾸며, 검증상태·재고·가격은 바꾸지 않습니다.',ui.ButtonSet.YES_NO);
  if(answer!==ui.Button.YES)return;
  var serial=dateSerial_(today_());
  rows.forEach(function(r){ctx.sheet.getRange(r,ctx.map['확인일']).setValue(serial).setNumberFormat('yyyy-mm-dd');});
  ss.toast(rows.length+'개 판매가 확인일을 갱신했습니다.','한눈단가',5);
}

function showUnitCartImport() {
  var body = '<h1>사이트 기록 가져오기</h1><p>사이트에서 내보낸 JSON을 붙여 넣으세요. 상품 100개·판매가 400개 범위 안에 저장합니다.</p>' +
    '<label>JSON<textarea id="json" rows="14" spellcheck="false" placeholder="{ &quot;schemaVersion&quot;: 1, ... }"></textarea></label>' +
    '<label class="check"><input type="checkbox" id="update">같은 ID의 기존 입력값도 갱신</label>' +
    '<p class="note">기본은 신규 ID만 추가합니다. 갱신을 선택하면 해당 ID의 입력값을 덮어씁니다. 기존 수식·다른 행은 유지하며 자동 삭제하지 않습니다.</p>' +
    '<label class="check"><input type="checkbox" id="settings">데이터 구분·가격 유효일수도 적용</label>' +
    '<button id="import">검사 후 가져오기</button><p id="status" role="status"></p>';
  var script = 'document.getElementById("import").addEventListener("click",function(){var b=this;b.disabled=true;document.getElementById("status").textContent="검사 중…";' +
    'google.script.run.withSuccessHandler(function(r){document.getElementById("status").textContent=r.message;b.disabled=false;})' +
    '.withFailureHandler(function(e){document.getElementById("status").textContent=e.message;b.disabled=false;})' +
    '.importUnitCartJson(document.getElementById("json").value,document.getElementById("update").checked,document.getElementById("settings").checked);});';
  SpreadsheetApp.getUi().showModalDialog(html_(body,script).setWidth(620).setHeight(650),'한눈단가 · JSON 가져오기');
}

function importUnitCartJson(text, updateExisting, applySettings) {
  var packet=validatePacket_(text);
  var lock=LockService.getDocumentLock();
  if(!lock.tryLock(10000))throw new Error('다른 입력 작업이 진행 중입니다. 잠시 후 다시 시도하세요.');
  try {
    var pc=context_(UC.products), oc=context_(UC.offers);
    var productPlan=planRows_(pc,packet.products,updateExisting===true);
    var offerPlan=planRows_(oc,packet.offers,updateExisting===true);
    var validProductIds=Object.create(null);
    pc.data.forEach(function(r){if(r[pc.map['상품ID']-1]!=='')validProductIds[String(r[pc.map['상품ID']-1])]=true;});
    packet.products.forEach(function(p){validProductIds[p.id]=true;});
    packet.offers.forEach(function(o){if(!validProductIds[o.productId])throw new Error('판매가 '+o.id+'의 상품ID '+o.productId+'가 없습니다. 상품을 함께 가져오거나 먼저 등록하세요.');});
    // All validation and capacity checks finish before the first sheet mutation.
    writePlan_(pc,productPlan,productCells_);
    writePlan_(oc,offerPlan,offerCells_);
    var props=PropertiesService.getDocumentProperties();
    productPlan.writes.forEach(function(w){props.setProperty(UC.categoryPrefix+w.item.id,w.item.category||'기타');});
    if(applySettings===true&&packet.settings){
      var summary=SpreadsheetApp.getActiveSpreadsheet().getSheetByName('비교요약');
      if(summary){summary.getRange('B4').setValue(packet.settings.mode);summary.getRange('E4').setValue(packet.settings.maxAgeDays);}
      props.setProperty(UC.metadataKey,JSON.stringify(packet.settings));
    }
    SpreadsheetApp.flush();
    return {products:productPlan.counts,offers:offerPlan.counts,
      message:'상품: 추가 '+productPlan.counts.added+' / 갱신 '+productPlan.counts.updated+' / 건너뜀 '+productPlan.counts.skipped+'건\n판매가: 추가 '+offerPlan.counts.added+' / 갱신 '+offerPlan.counts.updated+' / 건너뜀 '+offerPlan.counts.skipped+'건. 수식 칸은 보존했습니다.'};
  } finally {lock.releaseLock();}
}

function showUnitCartExport() {
  var body='<h1>사이트로 기록 옮기기</h1><p>JSON 파일을 다운로드한 뒤 사이트의 가져오기로 불러오세요. 가격 확인일은 기존 값 그대로 보존합니다.</p>'+
    '<textarea id="json" rows="15" readonly spellcheck="false"></textarea><div class="links"><button id="download" disabled>JSON 다운로드</button><button id="select" disabled>전체 선택</button></div><p id="status" role="status">읽는 중…</p>';
  var script='var payload="";google.script.run.withSuccessHandler(function(r){payload=r;document.getElementById("json").value=r;document.getElementById("status").textContent="현재 시트의 기록입니다. 파일을 내보내도 원본은 유지됩니다.";document.getElementById("download").disabled=false;document.getElementById("select").disabled=false;})'+
    '.withFailureHandler(function(e){document.getElementById("status").textContent=e.message;}).exportUnitCartJson();'+
    'document.getElementById("select").onclick=function(){var t=document.getElementById("json");t.focus();t.select();};'+
    'document.getElementById("download").onclick=function(){var url=URL.createObjectURL(new Blob([payload],{type:"application/json;charset=utf-8"}));var a=document.createElement("a");a.href=url;a.download="unitcart-sheets-"+new Date().toISOString().slice(0,10)+".json";a.click();setTimeout(function(){URL.revokeObjectURL(url);},1000);};';
  SpreadsheetApp.getUi().showModalDialog(html_(body,script).setWidth(640).setHeight(590),'한눈단가 · JSON 내보내기');
}

function exportUnitCartJson() {
  var ss=SpreadsheetApp.getActiveSpreadsheet(), summary=ss.getSheetByName('비교요약');
  var products=exportProductRows_(), oc=context_(UC.offers);
  var offers=oc.data.filter(function(r){return r[oc.map['판매가ID']-1]!=='';}).map(function(r){
    var g=function(k){return r[oc.map[k]-1];};
    return {id:String(g('판매가ID')),productId:String(g('상품ID')),platform:g('플랫폼'),seller:g('판매처'),name:g('상품명'),match:g('일치유형'),unit:g('비교단위'),
      quantity:numberOrNull_(g('총량')),price:numberOrNull_(g('상품가격')),shipping:numberOrNull_(g('배송비')),discount:numberOrNull_(g('적용할인'))||0,
      discountConfirmed:g('할인확인')==='예',delivery:g('배송유형'),official:g('공식몰확인')==='확인',officialEvidenceUrl:g('공식몰근거URL'),url:g('상품URL'),
      verifiedAt:dateString_(g('확인일')),stock:g('재고'),verified:g('검증상태')==='확인',isExample:g('데이터구분')==='예시',note:g('메모')};
  });
  var settings={mode:summary&&summary.getRange('B4').getValue()==='실제'?'실제':'예시',maxAgeDays:summary?Number(summary.getRange('E4').getValue())||7:7,includeSellerRocket:true};
  var saved=PropertiesService.getDocumentProperties().getProperty(UC.metadataKey);
  if(saved){try{settings.includeSellerRocket=JSON.parse(saved).includeSellerRocket!==false;}catch(e){}}
  var result={schemaVersion:1,exportedAt:new Date().toISOString(),settings:settings,products:products,offers:offers};
  // This also stops invalid manual rows or spreadsheet formula errors being exported as prices.
  return JSON.stringify(validatePacket_(JSON.stringify(result)),null,2);
}

function exportProductRows_() {
  var pc=context_(UC.products), props=PropertiesService.getDocumentProperties();
  return pc.data.filter(function(r){return r[pc.map['상품ID']-1]!=='';}).map(function(r){
    var g=function(k){return r[pc.map[k]-1];};
    return {id:String(g('상품ID')),name:g('상품명'),spec:g('브랜드·모델/규격'),query:g('검색어'),unit:g('비교단위'),
      costcoPrice:numberOrNull_(g('코스트코 결제금액')),costcoQuantity:numberOrNull_(g('총량')),costcoUnitPrice:numberOrNull_(g('직접입력 단가')),
      verifiedAt:dateString_(g('확인일')),isExample:g('데이터구분')==='예시',note:g('메모'),category:props.getProperty(UC.categoryPrefix+g('상품ID'))||'기타'};
  });
}

function selectedProduct_() {
  var ss=SpreadsheetApp.getActiveSpreadsheet(), r=ss.getActiveRange();
  if(!r||r.getRow()<UC.firstRow)return null;
  var name=r.getSheet().getName(), id='';
  if(name==='상품') {var pc=context_(UC.products);id=String(pc.sheet.getRange(r.getRow(),pc.map['상품ID']).getValue());}
  else if(name==='판매가') {var oc=context_(UC.offers);id=String(oc.sheet.getRange(r.getRow(),oc.map['상품ID']).getValue());}
  else if(name==='비교요약') id=String(r.getSheet().getRange(r.getRow(),1).getValue());
  return exportProductRows_().filter(function(p){return p.id===id;})[0]||null;
}

function context_(definition) {
  var sheet=SpreadsheetApp.getActiveSpreadsheet().getSheetByName(definition.name);
  if(!sheet)throw new Error('“'+definition.name+'” 시트가 없습니다. 한눈단가 템플릿을 Google Sheets로 변환한 뒤 실행하세요.');
  var width=Math.max(sheet.getLastColumn(),definition.name==='상품'?15:26);
  var headers=sheet.getRange(UC.headerRow,1,1,width).getValues()[0], map=Object.create(null);
  headers.forEach(function(v,i){if(v!==''){if(map[v])throw new Error('중복 열 제목: '+v);map[String(v).trim()]=i+1;}});
  definition.fields.forEach(function(k){if(!map[k])throw new Error(definition.name+' 시트 7행의 “'+k+'” 열을 찾을 수 없습니다. 열 제목을 복구하세요.');});
  if(sheet.getMaxRows()<UC.firstRow+definition.capacity-1)throw new Error(definition.name+'의 준비된 입력 범위가 삭제되었습니다. 템플릿 행과 수식을 복구하세요.');
  return {definition:definition,sheet:sheet,map:map,width:width,data:sheet.getRange(UC.firstRow,1,definition.capacity,width).getValues()};
}

function planRows_(ctx,items,updateExisting) {
  var byId=Object.create(null), free=[];
  ctx.data.forEach(function(r,i){var id=r[ctx.map[ctx.definition.id]-1];if(id===''){
    var partial=ctx.definition.fields.some(function(k){return r[ctx.map[k]-1]!=='';});
    if(partial)throw new Error(ctx.definition.name+' '+(i+UC.firstRow)+'행에 ID 없이 입력된 값이 있습니다. ID를 채우거나 해당 입력을 정리한 뒤 가져오세요.');
    free.push(i+UC.firstRow);
  }else{if(byId[id])throw new Error(ctx.definition.name+' 시트에 중복 ID '+id+'가 있습니다. 먼저 정리하세요.');byId[String(id)]=i+UC.firstRow;}});
  var counts={added:0,updated:0,skipped:0}, writes=[];
  items.forEach(function(item){var row=byId[item.id];if(row){if(updateExisting){writes.push({row:row,item:item});counts.updated++;}else counts.skipped++;}
    else{if(!free.length)throw new Error(ctx.definition.name+' 입력 한도 '+ctx.definition.capacity+'개를 넘습니다. 가져오기는 실행하지 않았습니다.');row=free.shift();byId[item.id]=row;writes.push({row:row,item:item});counts.added++;}});
  return {writes:writes,counts:counts};
}

function writePlan_(ctx,plan,mapper) {
  plan.writes.forEach(function(write){
    var obj=mapper(write.item), entries=Object.keys(obj).map(function(k){return {column:ctx.map[k],header:k,value:typeof obj[k]==='string'?safeCellText_(obj[k]):obj[k]};}).sort(function(a,b){return a.column-b.column;});
    var groups=[];
    entries.forEach(function(entry){var group=groups[groups.length-1];if(!group||group[group.length-1].column+1!==entry.column){group=[];groups.push(group);}group.push(entry);});
    groups.forEach(function(group){ctx.sheet.getRange(write.row,group[0].column,1,group.length).setValues([group.map(function(e){return e.value;})]);});
    ctx.sheet.getRange(write.row,ctx.map['확인일']).setNumberFormat('yyyy-mm-dd');
  });
}

function productCells_(p) {return {'상품ID':p.id,'상품명':p.name,'브랜드·모델/규격':p.spec,'검색어':p.query,'비교단위':p.unit,'코스트코 결제금액':blank_(p.costcoPrice),'총량':blank_(p.costcoQuantity),'직접입력 단가':blank_(p.costcoUnitPrice),'확인일':p.verifiedAt?dateSerial_(p.verifiedAt):'','데이터구분':p.isExample?'예시':'실제','메모':p.note};}
function offerCells_(o) {return {'판매가ID':o.id,'상품ID':o.productId,'플랫폼':o.platform,'판매처':o.seller,'상품명':o.name,'일치유형':o.match,'비교단위':o.unit,'총량':blank_(o.quantity),'상품가격':blank_(o.price),'배송비':blank_(o.shipping),'적용할인':o.discount,'할인확인':o.discountConfirmed?'예':'아니오','배송유형':o.delivery,'공식몰확인':o.platform==='네이버'?(o.official?'확인':'미확인'):'해당없음','공식몰근거URL':o.officialEvidenceUrl,'상품URL':o.url,'확인일':o.verifiedAt?dateSerial_(o.verifiedAt):'','재고':o.stock,'검증상태':o.verified?'확인':'미확인','데이터구분':o.isExample?'예시':'실제','메모':o.note};}

function validatePacket_(text) {
  if(typeof text!=='string'||text.length>UC.maxBytes)throw new Error('JSON은 1,000,000자 이하 텍스트로 입력하세요.');
  var x;try{x=JSON.parse(text);}catch(e){throw new Error('JSON 형식을 읽을 수 없습니다. 사이트에서 내보낸 파일 전체를 붙여 넣으세요.');}
  if(!x||typeof x!=='object'||Array.isArray(x)||x.schemaVersion!==1||!Array.isArray(x.products)||!Array.isArray(x.offers))throw new Error('지원 형식은 schemaVersion:1, products 배열, offers 배열입니다.');
  if(x.products.length>UC.products.capacity||x.offers.length>UC.offers.capacity)throw new Error('한 번에 상품 100개·판매가 400개까지 가져올 수 있습니다.');
  var seenP=Object.create(null),seenO=Object.create(null);
  var products=x.products.map(function(p){
    if(!p||typeof p!=='object')throw new Error('잘못된 상품 항목입니다.');
    var id=cleanId_(p.id,'상품ID');if(seenP[id])throw new Error('JSON 안의 상품ID가 중복됩니다: '+id);seenP[id]=true;
    if(typeof p.isExample!=='boolean')throw new Error(id+': 예시 구분 isExample은 true 또는 false여야 합니다.');
    return {id:id,name:cleanText_(p.name,'상품명',500,true),spec:cleanText_(p.spec,'규격',500),query:cleanText_(p.query,'검색어',500),unit:oneOf_(p.unit,UC.units,'비교단위'),
      costcoPrice:nonnegative_(p.costcoPrice,'코스트코 결제금액',true),costcoQuantity:positive_(p.costcoQuantity,'코스트코 총량',true),costcoUnitPrice:positive_(p.costcoUnitPrice,'직접입력 단가',true),
      verifiedAt:validDate_(p.verifiedAt),isExample:p.isExample===true,note:cleanText_(p.note,'메모',2000),category:cleanText_(p.category,'분류',500)||'기타'};
  });
  var offers=x.offers.map(function(o){
    if(!o||typeof o!=='object')throw new Error('잘못된 판매가 항목입니다.');
    var id=cleanId_(o.id,'판매가ID');if(seenO[id])throw new Error('JSON 안의 판매가ID가 중복됩니다: '+id);seenO[id]=true;
    if(typeof o.isExample!=='boolean')throw new Error(id+': 예시 구분 isExample은 true 또는 false여야 합니다.');
    var result={id:id,productId:cleanId_(o.productId,'상품ID'),platform:oneOf_(o.platform,['쿠팡','네이버'],'플랫폼'),seller:cleanText_(o.seller,'판매처',500),name:cleanText_(o.name,'판매 상품명',500,true),match:oneOf_(o.match,['동일','유사'],'일치유형'),
      unit:oneOf_(o.unit,UC.units,'비교단위'),quantity:positive_(o.quantity,'총량',true),price:nonnegative_(o.price,'상품가격',true),shipping:nonnegative_(o.shipping,'배송비',true),discount:nonnegative_(o.discount,'할인액',true)||0,
      discountConfirmed:o.discountConfirmed===true,delivery:oneOf_(o.delivery,UC.deliveries,'배송유형'),official:o.official===true,officialEvidenceUrl:validUrl_(o.officialEvidenceUrl),url:validUrl_(o.url),verifiedAt:validDate_(o.verifiedAt),
      stock:oneOf_(o.stock,['있음','품절','미확인'],'재고'),verified:o.verified===true,isExample:o.isExample===true,note:cleanText_(o.note,'메모',2000)};
    if(result.price!==null&&result.shipping!==null&&result.discount>result.price+result.shipping)throw new Error(id+': 할인액이 상품가격+배송비보다 큽니다.');
    return result;
  });
  var result={schemaVersion:1,exportedAt:typeof x.exportedAt==='string'?cleanText_(x.exportedAt,'내보낸 시각',50):new Date().toISOString(),products:products,offers:offers};
  if(x.settings){result.settings={mode:oneOf_(x.settings.mode,['예시','실제'],'데이터 구분'),maxAgeDays:positive_(x.settings.maxAgeDays,'가격 유효일수',false),includeSellerRocket:x.settings.includeSellerRocket!==false};if(result.settings.maxAgeDays>365||Math.floor(result.settings.maxAgeDays)!==result.settings.maxAgeDays)throw new Error('가격 유효일수는 1~365 정수입니다.');}
  return result;
}

function cleanId_(v,label){if(typeof v!=='string'||!/^[A-Za-z0-9가-힣_-]{1,100}$/.test(v))throw new Error(label+'는 1~100자 영문·숫자·한글 및 _ - 로 입력하세요.');return v;}
function cleanText_(v,label,max,required){if(v===undefined||v===null)v='';if(typeof v!=='string')throw new Error(label+'는 텍스트여야 합니다.');v=v.replace(/\u0000/g,'');if(v.length>max)throw new Error(label+'가 너무 깁니다 ('+max+'자 제한).');if(required&&!v.trim())throw new Error(label+'가 비어 있습니다.');return v;}
function oneOf_(v,allowed,label){if(allowed.indexOf(v)<0)throw new Error(label+' 값이 올바르지 않습니다: '+String(v));return v;}
function nonnegative_(v,label,nullable){if(v===null||v===undefined||v===''){if(nullable)return null;throw new Error(label+'가 비어 있습니다.');}if(typeof v!=='number'||!isFinite(v)||v<0||v>1e12)throw new Error(label+'는 0~1조 사이의 숫자여야 합니다.');return v;}
function positive_(v,label,nullable){var n=nonnegative_(v,label,nullable);if(n!==null&&n<=0)throw new Error(label+'는 0보다 커야 합니다.');return n;}
function validUrl_(v){v=cleanText_(v,'URL',2048);if(v&&!/^https?:\/\/[^\s<>"'`]+$/i.test(v))throw new Error('링크는 http:// 또는 https:// 주소여야 합니다.');if(v&&/^https?:\/\/[^/]*@/i.test(v))throw new Error('링크에 사용자명이나 비밀번호를 포함하지 마세요.');return v;}
function validDate_(v){if(v===undefined||v===null||v==='')return '';if(typeof v!=='string'||!/^\d{4}-\d{2}-\d{2}$/.test(v))throw new Error('확인일은 YYYY-MM-DD 형식입니다.');var d=new Date(v+'T12:00:00Z');if(!isFinite(d.getTime())||d.toISOString().slice(0,10)!==v)throw new Error('존재하지 않는 확인일입니다: '+v);return v;}
function dateSerial_(v){validDate_(v);return Math.round((Date.parse(v+'T00:00:00Z')-Date.UTC(1899,11,30))/86400000);}
function dateString_(v){if(v===''||v===null||v===undefined)return '';if(v instanceof Date)return Utilities.formatDate(v,SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone(),'yyyy-MM-dd');if(typeof v==='number')return new Date(Date.UTC(1899,11,30)+v*86400000).toISOString().slice(0,10);return validDate_(String(v));}
function numberOrNull_(v){if(v===''||v===null||v===undefined)return null;if(typeof v!=='number'||!isFinite(v))throw new Error('숫자 입력 칸에 텍스트 또는 수식 오류가 있습니다. 상품·판매가 시트의 숫자 칸을 확인하세요.');return v;}
function blank_(v){return v===null||v===undefined?'':v;}
function safeCellText_(v){return /^[\s\uFEFF]*[=+\-@]/.test(v)?"'"+v:v;}
function today_(){return Utilities.formatDate(new Date(),SpreadsheetApp.getActiveSpreadsheet().getSpreadsheetTimeZone(),'yyyy-MM-dd');}
function scriptJson_(v){return JSON.stringify(v).replace(/</g,'\\u003c').replace(/>/g,'\\u003e').replace(/&/g,'\\u0026').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029');}
function html_(body,script){return HtmlService.createHtmlOutput('<!doctype html><html lang="ko"><head><base target="_top"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font:14px/1.6 system-ui,sans-serif;color:#18312c;margin:20px}h1{font-size:22px;margin:0 0 8px}p{margin:10px 0}label{display:block;margin:12px 0 4px;font-weight:600}input,select,textarea,button{font:inherit;box-sizing:border-box}input:not([type=checkbox]),select,textarea{display:block;width:100%;border:1px solid #c3d1cb;border-radius:7px;padding:9px;margin-top:4px;background:white;color:#18312c}textarea{resize:vertical}button{border:0;background:#167258;color:white;border-radius:7px;padding:10px 15px;cursor:pointer}button:disabled{opacity:.55;cursor:wait}.links{display:flex;gap:10px;flex-wrap:wrap;margin:16px 0}.links a{background:#e9f4ee;color:#16583e;padding:9px 12px;border-radius:7px;text-decoration:none}.note{font-size:13px;color:#536960}.check{display:flex;gap:8px;align-items:flex-start;font-weight:400}.two{display:grid;grid-template-columns:1fr 1fr;gap:10px}#status{white-space:pre-wrap;color:#215c49;font-weight:600}input:focus,textarea:focus,select:focus{outline:2px solid #338b71;outline-offset:2px}</style></head><body>'+body+'<script>'+script+'</script></body></html>');}
